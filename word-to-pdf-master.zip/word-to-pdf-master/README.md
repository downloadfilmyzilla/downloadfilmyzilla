# word-to-pdf

```
npm install
```
use the command to install all the dependencies

```
node app.js
```

use the command to start the application

you will find the page on 
>localhost:3000
